# Bienvenidos en el Repo del Token Los Frutas "FPI SPL-Tokens"



Tus causas y tu maistro billeteria el bos...json 
mira     anarcrypt_tokens/fruit-token/contract-hashes.txt para los addresses 
y informationes del blockxhain como contractos y signaturas de los operationes de creation de la moneda frutos!
si no lencuentras quando buscas aqui... vas hasta:

[los  token billeterias y infos](https://github.com/RastaDjuss/anarcrypt_tokens/new/main/fruit-token/contrac-hashes.txt) 

## y voila!

